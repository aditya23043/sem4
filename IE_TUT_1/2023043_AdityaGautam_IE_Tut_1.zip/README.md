# Important Info
- All LTSpice files have been added in the respective folders along with the screenshots (.png) named appropriately

## Naming Convention for the files / folders
- 4.2V -> vm_4_2
- 5V -> vm_5
- 5.7V -> vm_5_7
- 10V -> vm_10

# Credits
- Aditya Gautam, 2023043
